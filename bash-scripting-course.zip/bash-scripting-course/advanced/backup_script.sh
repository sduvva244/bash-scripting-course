#!/bin/bash
tar -czf backup.tar.gz *.sh
echo "Backup created."