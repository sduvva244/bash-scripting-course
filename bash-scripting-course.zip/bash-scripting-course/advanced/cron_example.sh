#!/bin/bash
echo "Running cron task at $(date)" >> cron.log