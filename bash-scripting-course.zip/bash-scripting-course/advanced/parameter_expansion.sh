#!/bin/bash
name=""
echo "${name:-Default}"