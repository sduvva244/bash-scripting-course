#!/bin/bash
echo "Sample text" > file.txt
cat file.txt