#!/bin/bash
str="hello world"
echo "Length: ${#str}"