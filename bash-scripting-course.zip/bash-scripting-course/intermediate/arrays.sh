#!/bin/bash
arr=("one" "two" "three")
echo ${arr[@]}