#!/bin/bash
echo "First arg: $1"