#!/bin/bash
ls > /dev/null
echo $?