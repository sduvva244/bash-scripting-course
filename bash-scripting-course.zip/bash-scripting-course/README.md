# Bash Scripting Course

This repository contains examples from basic to advanced Bash scripting.