#!/bin/bash
name="John"
echo "Name is $name"